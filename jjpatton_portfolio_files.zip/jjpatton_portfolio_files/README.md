# JJPatton Personal Portfolio
This is one page portfolio page created by JJ Patton for the Udacity Front End Nanodegree program. The project is a personal portfolio page. This page features two content sections, projects portfolio, and it is fully responsive.

## Basic Usage
You can simply edit the HTML and CSS files included with the portfolio page in Atom, Brackets or in your favorite text editor to make changes.
The portfolio page HTML AND CSS was validated with W3C's Validators. 

## Page Structure
Header - Logo and Navigation
About Section
Skills Section
Projects Section
Contact Section
End Footer

## Credits
Made by @jjopatton. This portfolio project includes necolas’s normalize.css project.

## License
